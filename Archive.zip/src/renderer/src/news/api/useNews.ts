import { useQuery } from '@tanstack/react-query'
import { NewsPost } from '../types'

// Define the announcement response type
interface Announcement {
  id: string
  content: string
  createdAt: string
  updatedAt: string
  createdBy: string
  media?: Array<{
    type: 'image' | 'video'
    url: string
    alt?: string
  }>
}

const mapAnnouncementToNewsPost = (announcement: Announcement): NewsPost => {
  return {
    id: announcement.id,
    author: {
      name: announcement.createdBy,
      handle: announcement.createdBy.toLowerCase().replace(/\s+/g, '_'),
      avatarUrl: `https://unavatar.io/github/${announcement.createdBy}`,
      verified: false
    },
    content: announcement.content,
    createdAt: announcement.createdAt,
    media: announcement.media
  }
}

export const useNews = () => {
  return useQuery({
    queryKey: ['news'],
    queryFn: async () => {
      const data: Announcement[] = await window.api.news.getAnnouncements()
      return data.map(mapAnnouncementToNewsPost)
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
    refetchOnWindowFocus: false,
    refetchOnMount: true, // Force refetch on mount
    gcTime: 0 // Don't cache
  })
}
