import React from 'react'

interface VerifiedIconProps extends React.SVGProps<SVGSVGElement> {}

const VerifiedIcon: React.FC<VerifiedIconProps> = (props) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="28"
      height="28"
      viewBox="0 0 28 28"
      fill="none"
      {...props}
    >
      <g clipPath="url(#clip0_8_46)">
        <rect
          x="5.88818"
          width="22.89"
          height="22.89"
          transform="rotate(15 5.88818 0)"
          fill="#3385ff"
        />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M20.543 8.7508L20.549 8.7568C21.15 9.3578 21.15 10.3318 20.549 10.9328L11.817 19.6648L7.45 15.2968C6.85 14.6958 6.85 13.7218 7.45 13.1218L7.457 13.1148C8.058 12.5138 9.031 12.5138 9.633 13.1148L11.817 15.2998L18.367 8.7508C18.968 8.1498 19.942 8.1498 20.543 8.7508Z"
          fill="white"
        />
      </g>
      <defs>
        <clipPath id="clip0_8_46">
          <rect width="28" height="28" fill="white" />
        </clipPath>
      </defs>
    </svg>
  )
}

export default VerifiedIcon
