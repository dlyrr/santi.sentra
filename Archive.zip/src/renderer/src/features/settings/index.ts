export { default } from './SettingsTab'
