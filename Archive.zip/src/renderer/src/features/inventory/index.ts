export { default } from './InventoryTab'
