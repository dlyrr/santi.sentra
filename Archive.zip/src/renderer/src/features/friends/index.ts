export { default } from './FriendsTab'
