import React, { useState, useEffect } from 'react'
import { BadgeCheck } from 'lucide-react'
import { Avatar, AvatarImage, AvatarFallback } from '@renderer/components/UI/display/Avatar'
import { Card } from '@renderer/components/UI/display/Card'
import { cn } from '@renderer/lib/utils'
import { NewsPost } from '../types'

interface NewsCardProps {
  post: NewsPost
}

const formatTimeAgo = (dateString: string): string => {
  const date = new Date(dateString)
  const now = new Date()
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  // Don't show seconds, start from minutes
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 7) return `${days}d ago`
  const weeks = Math.floor(days / 7)
  if (weeks < 4) return `${weeks}w ago`
  const months = Math.floor(days / 30)
  if (months >= 1) return `${months}mo ago`
  // If months is 0 but weeks >= 4, still show weeks
  return `${weeks}w ago`
}

const formatFullDate = (dateString: string): string => {
  try {
    if (!dateString) return 'No date'
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return 'Invalid date'
    
    // Simple manual formatting to avoid any Intl issues
    const year = date.getFullYear()
    const month = date.toLocaleString('en-US', { month: 'short' })
    const day = date.getDate()
    const hours = date.getHours()
    const minutes = date.getMinutes()
    const ampm = hours >= 12 ? 'PM' : 'AM'
    const displayHours = hours % 12 || 12
    const displayMinutes = minutes.toString().padStart(2, '0')
    
    return `${month} ${day}, ${year} at ${displayHours}:${displayMinutes} ${ampm}`
  } catch (error) {
    return 'Date error'
  }
}

const formatContent = (content: string) => {
  const urlRegex = /(https?:\/\/[^\s]+)/g
  const parts = content.split(urlRegex)

  return parts.map((part, i) => {
    if (part.match(urlRegex)) {
      return (
        <a
          key={i}
          href={part}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:underline break-all"
          onClick={(e) => e.stopPropagation()}
        >
          {part}
        </a>
      )
    }
    return part
  })
}

export const NewsCard: React.FC<NewsCardProps> = ({ post }) => {
  const [relativeTime, setRelativeTime] = useState(() => formatTimeAgo(post.createdAt))

  useEffect(() => {
    // Update timestamp every 30 seconds for more responsive updates
    const interval = setInterval(() => {
      setRelativeTime(formatTimeAgo(post.createdAt))
    }, 30000)

    return () => clearInterval(interval)
  }, [post.createdAt])

  return (
    <Card className="bg-[var(--color-surface)] border-[var(--color-border)] p-5" disableHover>
      <div className="flex gap-4">
        <div className="flex flex-col items-center shrink-0">
          <Avatar className="h-12 w-12 border-2 border-[var(--color-border)] shadow-sm">
            <AvatarImage src={post.author.avatarUrl} alt={post.author.name} />
            <AvatarFallback>{post.author.name[0]}</AvatarFallback>
          </Avatar>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center mb-1.5">
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-[var(--color-text-primary)] text-[15px]">
                  {post.author.name}
                </span>
                {post.author.verified && (
                  <BadgeCheck className="w-4 h-4 text-[var(--accent-color)] flex-shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
                <span>@{post.author.handle}</span>
                <span>·</span>
                <span title={formatFullDate(post.createdAt)} className="cursor-help">
                  {relativeTime}
                </span>
              </div>
            </div>
          </div>

          {post.content && (
            <div className="text-[var(--color-text-secondary)] whitespace-pre-wrap mb-4 text-[15px] leading-relaxed font-normal">
              {formatContent(post.content)}
            </div>
          )}

          {post.media && post.media.length > 0 && (
            <div
              className={cn(
                'grid gap-0.5 mb-4 rounded-xl overflow-hidden border border-[var(--color-border-subtle)]',
                post.media.length === 1 ? 'grid-cols-1' : 'grid-cols-2',
                post.media.length >= 3 && 'grid-rows-2'
              )}
            >
              {post.media.map((media, index) => {
                const isSingle = post.media!.length === 1
                const isThree = post.media!.length === 3

                return (
                  <div
                    key={index}
                    className={cn(
                      'relative bg-[var(--color-surface-strong)] overflow-hidden cursor-pointer',
                      isSingle ? 'w-full h-full' : 'aspect-square',
                      isThree && index === 0 ? 'row-span-2 aspect-auto h-full' : ''
                    )}
                  >
                    {media.type === 'image' ? (
                      <img
                        src={media.url}
                        alt={media.alt || 'Post media'}
                        className={cn(
                          'w-full h-full',
                          isSingle ? 'object-contain max-h-[500px] bg-black/50' : 'object-cover'
                        )}
                      />
                    ) : (
                      <video
                        src={media.url}
                        poster={media.alt}
                        controls
                        className="w-full h-full object-cover"
                        onClick={(e) => e.stopPropagation()}
                      />
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}
