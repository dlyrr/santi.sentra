export { default } from './AvatarTab'
