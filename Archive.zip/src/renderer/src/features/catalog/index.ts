export { default } from './CatalogTab'
