import { ipcMain } from 'electron'
import { net } from 'electron'
import { announcementService } from './AnnouncementService'

export function registerNewsHandlers(): void {
  // Get announcements (remote github sync with fallback to local)
  ipcMain.handle('news:get-announcements', async () => {
    try {
      // attempt to fetch remote news.js from installer repo
      const url =
        'https://raw.githubusercontent.com/sashaga2a24/installer/main/news.js'
      try {
        console.log('[News] Fetching announcements from GitHub...')
        const resp = await net.fetch(url)
        if (resp.ok) {
          const text = await resp.text()
          const remote = parseRemoteNewsJs(text)
          if (Array.isArray(remote) && remote.length) {
            console.log('[News] Successfully fetched', remote.length, 'announcements from GitHub')

            // Sort by creation date descending (newest first)
            return remote.sort((a, b) =>
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            )
          }
          console.warn('[News] GitHub response not an array or empty')
        } else {
          console.warn('[News] GitHub fetch failed with status:', resp.status)
        }
      } catch (err) {
        console.warn('[News] Failed to sync news from GitHub:', err)
      }

      // Fallback to local test data if GitHub fails
      try {
        const fs = require('fs')
        const path = require('path')
        const newsPath = path.join(process.cwd(), 'news.js')

        if (fs.existsSync(newsPath)) {
          const text = fs.readFileSync(newsPath, 'utf8')
          const parsed = parseRemoteNewsJs(text)
          if (Array.isArray(parsed) && parsed.length) {
            console.log('[News] Using local fallback news, items:', parsed.length)
            return parsed.sort((a, b) => 
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            )
          }
        }
      } catch (err) {
        console.warn('[News] Failed to load local fallback:', err)
      }

      console.log('[News] No news available, returning empty array')
      return []
    } catch (error) {
      console.error('[News] Error getting announcements:', error)
      throw error
    }
  })

  // Helper to interpret JS file contents exported via module.exports
  function parseRemoteNewsJs(text: string): any[] {
    try {
      // Remove any BOM or whitespace at start
      text = text.trim()
      
      // look for "module.exports = [...]" pattern
      const match = text.match(/module\.exports\s*=\s*(\[[\s\S]*\])\s*$/)
      if (match && match[1]) {
        let jsonStr = match[1]
        
        // Convert JavaScript object notation to valid JSON
        // Replace unquoted property names with quoted ones
        // This handles both single and double quoted values
        jsonStr = jsonStr.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":')
        
        try {
          const parsed = JSON.parse(jsonStr)
          console.log('[News] Parsed remote news from GitHub, items:', Array.isArray(parsed) ? parsed.length : 0)
          return Array.isArray(parsed) ? parsed : []
        } catch (parseErr) {
          console.warn('[News] JSON parse error, trying eval fallback:', parseErr)
          // Fallback: try eval (safer since we just fetched it)
          const evaluated = eval('(' + jsonStr + ')')
          console.log('[News] Eval parsed remote news from GitHub, items:', Array.isArray(evaluated) ? evaluated.length : 0)
          return Array.isArray(evaluated) ? evaluated : []
        }
      }
      console.warn('[News] Could not find module.exports pattern in remote news.js')
    } catch (e) {
      console.warn('[News] Unable to parse remote news.js:', e)
    }
    return []
  }

  // Create announcement
  ipcMain.handle(
    'news:create-announcement',
    async (_event, content: string, username: string, media?: any[]) => {
      try {
        return announcementService.createAnnouncement(content, username, media)
      } catch (error) {
        console.error('Error creating announcement:', error)
        throw error
      }
    }
  )

  // Delete announcement (admin only)
  ipcMain.handle('news:delete-announcement', (_event, id: string) => {
    try {
      const success = announcementService.deleteAnnouncement(id)
      return { success }
    } catch (error) {
      console.error('Error deleting announcement:', error)
      throw error
    }
  })

  // Update announcement (admin only)
  ipcMain.handle('news:update-announcement', (_event, id: string, updates: any) => {
    try {
      const result = announcementService.updateAnnouncement(id, updates)
      if (!result) {
        throw new Error('Announcement not found')
      }
      return result
    } catch (error) {
      console.error('Error updating announcement:', error)
      throw error
    }
  })
}

