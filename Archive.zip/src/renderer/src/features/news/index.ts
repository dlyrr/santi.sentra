export { default } from './NewsTab'
