import React, { useState, useEffect } from 'react'
import { Send, AlertCircle, CheckCircle, X } from 'lucide-react'
import { cn } from '../../../lib/utils'

interface NewsAdminPanelProps {
  username: string
  isOpen: boolean
  onClose: () => void
  onAnnouncementCreated?: () => void
}

export const NewsAdminPanel: React.FC<NewsAdminPanelProps> = ({
  username,
  isOpen,
  onClose,
  onAnnouncementCreated
}) => {
  const [content, setContent] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setContent('')
      setMessage(null)
    }
  }, [isOpen])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim()) {
      setMessage({ type: 'error', text: 'Announcement content cannot be empty' })
      return
    }

    setIsSubmitting(true)
    try {
      await window.api.news.createAnnouncement(content, username)
      setMessage({ type: 'success', text: 'Announcement posted successfully!' })

      // Reset form after success
      setTimeout(() => {
        setMessage(null)
        onAnnouncementCreated?.()
        onClose()
      }, 2000)
    } catch (error) {
      setMessage({
        type: 'error',
        text: `Failed to create announcement: ${error instanceof Error ? error.message : 'Unknown error'}`
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClose = () => {
    if (!isSubmitting) {
      onClose()
    }
  }

  if (!isOpen) {
    return null
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
        <div className="sticky top-0 bg-[var(--color-surface)] border-b border-[var(--color-border)] p-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-[var(--color-text-primary)]">Post Announcement</h2>
          <button
            onClick={handleClose}
            className="text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">
              Announcement Content
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your announcement here..."
              className="w-full px-4 py-3 bg-[var(--color-surface-strong)] border border-[var(--color-border)] text-[var(--color-text-primary)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] resize-none"
              rows={5}
              disabled={isSubmitting}
            />
            <p className="text-xs text-[var(--color-text-muted)] mt-1">
              {content.length} characters
            </p>
          </div>

          {message && (
            <div
              className={cn(
                'flex items-center gap-2 p-3 rounded-lg',
                message.type === 'success'
                  ? 'bg-green-500/20 text-green-700 border border-green-500/30'
                  : 'bg-red-500/20 text-red-700 border border-red-500/30'
              )}
            >
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 flex-shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
              )}
              <span className="text-sm">{message.text}</span>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              disabled={isSubmitting || !content.trim()}
              className="flex-1 bg-[var(--accent-color)] hover:bg-opacity-90 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {isSubmitting ? 'Posting...' : 'Post Announcement'}
            </button>
            <button
              type="button"
              onClick={handleClose}
              disabled={isSubmitting}
              className="px-6 bg-[var(--color-surface-strong)] hover:bg-[var(--color-surface-muted)] border border-[var(--color-border)] text-[var(--color-text-primary)] font-medium py-2 rounded-lg transition-all duration-200 disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
